package com.example.quepaisehesse;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "countries")
public class CountryEntity {
    @PrimaryKey(autoGenerate = true)
    public int id;

    public String name;
}
