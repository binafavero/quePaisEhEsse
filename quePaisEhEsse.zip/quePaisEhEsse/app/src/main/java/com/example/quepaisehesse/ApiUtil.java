package com.example.quepaisehesse;

import android.util.Log;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class ApiUtil {
    private static final String API_URL = "https://falabr.cgu.gov.br/api/paises";

    public static List<CountryModel> getCountries(MainActivity mainActivity) {
        List<CountryModel> countryList = new ArrayList<>();

        try {
            URL url = new URL(API_URL);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");

            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder response = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                response.append(line);
            }

            JSONArray jsonArray = new JSONArray(response.toString());
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                String countryName = jsonObject.getString("nome");
                CountryModel country = new CountryModel();
                country.setName(countryName);
                countryList.add(country);
            }

            reader.close();
            connection.disconnect();

        } catch (IOException | JSONException e) {
            Log.e("ApiUtil", "Error: " + e.getMessage());
        }

        return countryList;
    }

}