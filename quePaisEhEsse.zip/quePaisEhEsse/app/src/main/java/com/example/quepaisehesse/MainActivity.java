package com.example.quepaisehesse;

import android.os.AsyncTask;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import java.util.List;
public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private CountryAdapter adapter;
    private SwipeRefreshLayout swipeRefreshLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));


        adapter = new CountryAdapter();
        recyclerView.setAdapter(adapter);


        swipeRefreshLayout.setOnRefreshListener(() -> {

            new ApiTask().execute();
        });


        new ApiTask().execute();
    }

    private class ApiTask extends AsyncTask<Void, Void, List<CountryModel>> {
        @Override
        protected List<CountryModel> doInBackground(Void... voids) {
            return ApiUtil.getCountries(MainActivity.this);
        }

        @Override
        protected void onPostExecute(List<CountryModel> countryList) {
            super.onPostExecute(countryList);

            adapter.setCountries(countryList);

            swipeRefreshLayout.setRefreshing(false);
        }
    }
}