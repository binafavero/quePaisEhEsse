package com.example.quepaisehesse;

public class CountryModel {
    private String name;

    public CountryModel() {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String countryName) {
    }
}
